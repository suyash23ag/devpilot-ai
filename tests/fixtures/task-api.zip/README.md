# Task API
A minimal in-memory task API built with Express.
Install dependencies with npm install. Run npm start.
GET /api/tasks lists tasks; POST /api/tasks accepts a JSON title.
No database is configured. Tasks are lost on restart.
