import express from 'express';
const app = express();
app.use(express.json());
const tasks = [];
app.get('/api/tasks', (req, res) => res.json(tasks));
app.post('/api/tasks', (req, res) => {
  if (typeof req.body.title !== 'string') return res.status(400).json({error: 'title required'});
  tasks.push({id: tasks.length + 1, title: req.body.title});
  res.status(201).json(tasks.at(-1));
});
app.listen(3000, '127.0.0.1');
