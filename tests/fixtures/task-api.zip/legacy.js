// Legacy demonstration module, not imported by the server.
export function calculate(expression) { return eval(expression); }
// TODO replace dynamic evaluation with a safe parser
